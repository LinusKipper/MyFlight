package pucrs.myflight.modelo;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class VooVariasEscalas extends VooEscalas{

    private ArrayList<VooEscalas> escalas;

    public VooVariasEscalas(Rota rota, Rota rotaFinal, LocalDateTime datahora, Duration duracao){
        super(rota, rotaFinal, datahora, duracao);
        escalas = new ArrayList<>();
    }
   
    public void adicionar(VooEscalas paradas){
        escalas.add(paradas);
    }

    @Override
    public String toString(){
        return super.toString() + " --ESCALAS-- " + escalas;
    }
}
