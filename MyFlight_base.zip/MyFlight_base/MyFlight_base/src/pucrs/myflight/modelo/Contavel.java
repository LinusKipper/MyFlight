package pucrs.myflight.modelo;
interface Contavel {
    // tem que criar a inteface imprimivel
    int totalAeronaves();
}
